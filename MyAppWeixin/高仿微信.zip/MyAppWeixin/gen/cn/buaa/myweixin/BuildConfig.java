/** Automatically generated file. DO NOT MODIFY */
package cn.buaa.myweixin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}